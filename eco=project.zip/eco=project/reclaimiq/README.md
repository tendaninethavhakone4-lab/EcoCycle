# EcoCycle — Recycling & Informal Pickers Platform

A full SaaS system: pure HTML/CSS/JavaScript frontend + Node.js/Express backend + Supabase (with mock fallback).

## What's inside

```
EcoCycle/
├── frontend/                       # Pure HTML/CSS/JS — no build step
│   ├── AuthScreens/                # Landing, Login, Register, ForgotPassword
│   ├── UserScreens/                # 13 user screens
│   ├── AdminScreens/               # 12 admin screens
│   ├── SuperAdminScreens/          # 13 superadmin screens
│   └── assets/
│       ├── css/styles.css          # Design system (#549C39 / #336700 / #F7EEE0)
│       └── js/app.js               # Auth, API client, sidebar, modals, tabs
└── backend/                        # Node.js + Express
    ├── server.js                   # Entry point — also serves the frontend
    ├── routes/                     # 19 route files covering all API endpoints
    ├── lib/                        # auth, supabase client, mock data
    ├── db/schema.sql               # Supabase schema
    ├── package.json
    └── .env.example
```

## Quick start (mock data — zero config)

```bash
cd backend
cp .env.example .env       # USE_MOCK=true is already set
npm install
npm start
```

Then open: <http://localhost:4000/AuthScreens/LandingPage.html>

**Demo accounts** (password: `demo1234`):
- `user@EcoCycle.app` → User workspace
- `admin@EcoCycle.app` → Admin console
- `superadmin@EcoCycle.app` → Super Admin suite

## Connecting to Supabase

1. Create a Supabase project at <https://supabase.com>
2. Open the **SQL Editor** and run `backend/db/schema.sql`
3. Edit `backend/.env`:
   ```
   USE_MOCK=false
   SUPABASE_URL=https://YOUR-PROJECT.supabase.co
   SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
   JWT_SECRET=a-long-random-string
   ```
4. Restart: `npm start`

> ⚠️ The service role key bypasses RLS — keep `.env` server-side only.

## Roles & flow

- **AUTH:** Landing → Login/Register → role check → role-specific dashboard
- **USER:** Dashboard → Pickers → QR Scan → Transaction Wizard → Ledger → Income → Inventory → Marketplace → Logistics → Insights → Settings
- **ADMIN:** Dashboard Hub → Picker Oversight → Ledger → Prices → Inventory → Sales → Analytics → Environmental → Smart Insights → Staff → Support → Reports
- **SUPERADMIN:** Executive Hub → Branches → Users → Global Analytics → Global Impact → AI → Geo → Rankings → Audit → Reports → Settings → Alerts → Escalated Support

## API endpoints (all wired in `backend/routes/`)

```
AUTH        POST   /api/auth/register | /login | /logout | /forgot-password | /reset-password
            GET    /api/auth/me
USERS       GET POST PUT DELETE /api/users[/:id]   PUT /api/users/:id/role
PICKERS     GET POST PUT DELETE /api/pickers[/:id] GET /api/pickers/:id/qr|/transactions|/earnings
TRANSACTIONS GET POST PUT DELETE /api/transactions[/:id]   GET /api/transactions/ledger
PRICES      GET PUT /api/prices                    GET /api/prices/history
INVENTORY   GET /api/inventory[/:material]  POST /api/inventory/update  GET /api/inventory/alerts
SALES       GET POST /api/sales[/:id]   POST /api/sales/:id/complete
INCOME      GET /api/income
PAYOUTS     GET POST /api/payouts
ANALYTICS   GET /api/analytics[/branch/:id|/global|/leaderboard]
IMPACT      GET /api/impact[/global]
REPORTS     GET POST /api/reports     GET /api/reports/:id/export
SUPPORT     GET POST PUT /api/support[/:id]   POST /api/support/:id/escalate
ALERTS      GET /api/alerts           PUT /api/alerts/:id/read
AUDIT       GET /api/audit[/:id]
BRANCHES    GET POST PUT DELETE /api/branches[/:id]
INSIGHTS    GET /api/insights[/forecast|/recommendations]
LOGISTICS   GET /api/logistics/pickups|/routes   POST /api/logistics/assign
SETTINGS    GET PUT /api/settings
```

## System logic

**Transaction engine** — when a transaction is saved:
1. Insert into `transactions` (ledger)
2. Add `weight` to `picker.total_kg` (earnings)
3. Add `weight` to `inventory[material].stock_kg`
4. Update analytics aggregates
5. Recompute environmental impact (CO₂ ≈ kg × 1.7)

**Inventory:** `available = stock − reserved`, low-stock alert if `available < threshold`.
**Sales:** validates stock, decrements `inventory[material]`, records sale.
**Pricing:** `PUT /api/prices` updates rates and writes to `price_history`.

## Notes

- Each frontend page calls `Auth.requireRole([...])` and renders the role-aware sidebar via `renderShell(role)`.
- If the API isn't running, login still works with the demo accounts (offline fallback) so you can preview every screen.
- The frontend is also served by the Express backend, so a single `npm start` gives you everything on `localhost:4000`.
